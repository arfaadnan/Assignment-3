const phones = [{
        Model: "3310s",
        Brand: "Samsung",
        Price: "25000",
        Camera: "12MP"
    },
    {
        Model: "2100",
        Brand: "Apple",
        Price: "80000",
        Camera: "16MP"
    },
    {
        Model: "3310s",
        Brand: "Apple",
        Price: "18000",
        Camera: "40MP"
    },
    {
        Model: "3310",
        Brand: "Samsung",
        Price: "15000",
        Camera: "12MP"
    },
    {
        Model: "2100",
        Brand: "Apple",
        Price: "18080",
        Camera: "16MP"
    },
    {
        Model: "2100",
        Brand: "Oppo",
        Price: "28090",
        Camera: "45MP"
    },
    {
        Model: "3310",
        Brand: "Samsung",
        Price: "23500",
        Camera: "12MP"
    },
    {
        Model: "2100",
        Brand: "Apple",
        Price: "83300",
        Camera: "16MP"
    },
    {
        Model: "2100",
        Brand: "Oppo",
        Price: "83200",
        Camera: "16MP"
    },
    {
        Model: "2100",
        Brand: "Apple",
        Price: "33800",
        Camera: "50MP"
    },
    {
        Model: "3310s",
        Brand: "Nokia",
        Price: "34800",
        Camera: "65MP"
    },
    {
        Model: "2100",
        Brand: "Apple",
        Price: "44800",
        Camera: "60MP"
    },
];

const hintValues = {};


const uniqueValues = {
    Brand: Array.from(new Set(phones.map(phone => phone.Brand))),
    Model: Array.from(new Set(phones.map(phone => phone.Model))),
    Price: Array.from(new Set(phones.map(phone => phone.Price))),
    Camera: Array.from(new Set(phones.map(phone => phone.Camera))),
};

document.getElementById('filterValue').addEventListener('input', suggestValues);

function suggestValues() {
    const filterOption = document.getElementById('filterOptions').value;
    const inputField = document.getElementById('filterValue');
    const filterValue = inputField.value.toLowerCase();

    const suggestions = uniqueValues[filterOption].filter(value =>
        value.toLowerCase().includes(filterValue)
    );

    inputField.setAttribute('list', 'suggestions');
    const datalist = document.createElement('datalist');
    datalist.id = 'suggestions';
    suggestions.forEach(suggestion => {
        const option = document.createElement('option');
        option.value = suggestion;
        datalist.appendChild(option);
    });
    inputField.parentNode.appendChild(datalist);


    // Trigger suggestValues function when the filter option changes
    document.getElementById('filterOptions').addEventListener('change', suggestValues);

    // Trigger suggestValues function when the input field gains focus
    document.getElementById('filterValue').addEventListener('focus', suggestValues);

    const suggestionsList = document.getElementById('suggestions');
    suggestionsList.innerHTML = '';

    suggestions.forEach(suggestion => {
        const listItem = document.createElement('li');
        listItem.textContent = suggestion;
        listItem.addEventListener('click', () => {
            inputField.value = suggestion;
            suggestionsList.style.display = 'none';
        });
        suggestionsList.appendChild(listItem);
    });

    suggestionsList.style.display = suggestions.length ? 'block' : 'none';
}

function initializeSuggestions() {
    const suggestionsList = document.getElementById('suggestions');
    suggestionsList.innerHTML = '';
    suggestionsList.style.display = 'none';
}

document.getElementById('filterValue').addEventListener('focus', suggestValues);

document.getElementById('filterOptions').addEventListener('change', () => {
    document.getElementById('filterValue').value = ''; // Clear the input field
});
document.getElementById('filterOptions').addEventListener('change', initializeSuggestions);


function filterPhones() {
    const filterOption = document.getElementById('filterOptions').value;
    const filterValue = document.getElementById('filterValue').value.toLowerCase();

    const filteredPhones = phones.filter(phone => phone[filterOption].toLowerCase().includes(filterValue));

    displayPhones(filteredPhones);
}

const properties = Object.keys(phones[0]); // Get properties from the first phone object
properties.forEach(property => {
    const uniqueValues = Array.from(new Set(phones.map(phone => phone[property])));
    hintValues[property] = uniqueValues;
});

function filterByProperty(property, value) {
    const filteredPhones = phones.filter(phone => phone[property] === value);
    displayPhones(filteredPhones);
}


function showHints(filterOption) {
    const hintsElement = document.getElementById('hints');
    hintsElement.innerHTML = '';

    hintValues[filterOption].forEach(hint => {
        const hintItem = document.createElement('div');
        const link = document.createElement('a');
        link.href = '#';
        link.textContent = hint;
        link.addEventListener('click', () => {
            filterByProperty(filterOption, hint);
        });
        hintItem.appendChild(link);
        hintsElement.appendChild(hintItem);
    });
}

function displayPhones(phones) {
    const phoneList = document.getElementById('phoneList');
    const noResults = document.getElementById('noResults');
    const errorMessage = document.getElementById('errorMessage');
    const hintsElement = document.getElementById('hints');
    hintsElement.innerHTML = '';
    phoneList.innerHTML = '';
    if (phones.length === 0) {
        noResults.style.display = 'block';
        phoneList.innerHTML = ''; // Clear the phone list
        const filterOption = document.getElementById('filterOptions').value;

        switch (filterOption) {
            case 'Model':
                errorMessage.textContent = `No Model Found. Available Models are:`;
                showHints('Model');
                break;
            case 'Brand':
                errorMessage.textContent = `No Brand Found. Available Brands are:`;
                showHints('Brand');
                break;
            case 'Price':
                errorMessage.textContent = `No Price Found. Available Price are:`;
                showHints('Price');
                break;
            case 'Camera':
                errorMessage.textContent = `No Camera Found. Available Cameras are:`;
                showHints('Camera');
                break;
            default:
                errorMessage.textContent = `No ${filterOption.toLowerCase()} found`;
                break;
        }
    } else {
        noResults.style.display = 'none';
        phones.forEach(phone => {
            const col = document.createElement('div');
            col.className = 'col-md-4 mb-3';
            col.innerHTML = `<div class="card">
      <div class="card-body">
        <h5 class="card-title">${phone.Model}</h5>
        <p class="card-text">Brand: ${phone.Brand}</p>
        <p class="card-text">Price: ${phone.Price}</p>
        <p class="card-text">Camera: ${phone.Camera}</p>
      </div>
    </div>`;
            phoneList.appendChild(col);
        });
    }


}